:::::::::::::::::::::: �2007 - 2010 OneLeaf (Kip Chatterson) ::::::::::::::::::::::


::::::::::::::::::
:: PROGRAM INFO ::
::::::::::::::::::

Program Name........: GenMce_Redux
Version.............: 0.88.3 
Author..............: Kip Chatterson
License Type........: Beverageware - 1 or a six pack depending on usage and situation(see GenMce_redux_EULA.txt)
Limitations.........: 10 day trial - see file mentioned above.
Paid................: 1 beverage or 1 six pack depending on situation
File Size...........: 1 meg
OS..................: WinXp and up
Release Date........: 6/18/2011
Languages...........: English

:::::::::::::
:: CONTACT ::
:::::::::::::

Email...............: genmce@yahoo.com


:::::::::::::::::::::::::::::
::     Change log          ::
:::::::::::::::::::::::::::::

v0.88.3
- button setup and ini reads... omg this thing has been busted for 6 months... 
  no one told me... sheesh.
- testing on audition.  
v.0.88.2
 - Can't believe no one noticed there was no way to set up controller translations?
   Added setup to menu so ppl can pick controllers to change.
 - Combined into one program - no more separate reaper file
 - If you are using with Reaper - get Klinke's plugin for advanced features.
 - Changed ch select to ` + fkey
 - changed vpot select to tab + fkey
 - Need to get back to my own life - don't know if there will be any updates after this.

v.0.88
Changed version numbers.
This version is NOT intended for REAPER with Klinke's plugin.
It will work with the generic reaper mackie csurf.

LCD - emuation - built in - thanks dorfl68, you rock!

revised gui - abandoned the blue. I like it better. Sorry if you like the blue.

Added tray menu items
- show keys
- center lcd
- display postion - stored
- beverageware info
- link to website

support for Sonar added. - Not tested
"leftctrl" + "backspace" to send connect (system exclusive) message.

Adobe Audition - not tested and refined.

do not forget to open genmce first, then open daw.
Pause does not disable midi conversion - only hotkey commands.

Combined into one script - thanks dorfl68 for the tip!

:::::::::::::::::::::::::::::
:: DESCRIPTION or/and USES ::
:::::::::::::::::::::::::::::

Translate you midi controller to mackie control emulation

Copy folder to location of your choice, just keep the files in the folder.

click the icon for Genmce_redux - it will run 
On first run it will 
	- generate a new .ini file with the title/version of GenMce_Redux.
	- ask for midi ports.
	- You select all three 
	- MCU input port - is new.
		That is the port in host's control surface dialog for midi output.
		It is where fader feedback occurs.

Tray menu -
	
	midiset = pick your ports, if you started from scratch you already did it.
	
	setup = here is where you will enter you controller info.
	More to come soon (see above for what is added)

*remember to reload this program after you change settings - either midi ports or setup settings.


Midi monitor - input obvious, output translated output.

	Fader postions are in yellow, below the midi monitor.
		When you reload the project, all those should be filled in.
		If they are blank then the fader will drop to zero when you touch it.
		Also - in the main gui (the one that looks like keymce gui) there is sync 
		that shows L when all the values are received on the fader postion.

Faders - set on setup use the midi monitor to set up your faders, ch  and cc#
Vpots and mfms the same way.

;*************************************************
;* 	Midi Routing is the hardest part!
;*************************************************

External controller > Genmce_redux midi input port
Genmce Midi output port > host mackie control surface midi input
host mackie ocntrol surface midi ouput  > Genmce Feedback (daw MCU port)

;*************************************************
;* 		Hotkey commands 
;*************************************************
Active PC keyboard commands 

Pause - on you keyboard will pause hotkeys ONLY - midi translation still occurs.

multifunction mutes F1-F8 keys. Single press = mute / double = solo / triple = arm


lwin+f1-f8 single = chsel / double = vpot select
* vpot select on reaper will reset pan to center for track like f8 will be track 8.


f10 - Single press = flip (swap vpots for faders)
      double press = Returns (Live Only)

f11 - single press = Plugin 
      double press = EQ - depending on daw (LIVE and REAPER does not support EQ)

f12 - Single press = Pan
      Double press = Sends

jog wheel on midi or mouse wheel... left ctrl + mouse wheel.

Thinking of moving track mfm's to the buttons 1 - 8...

After reload you will also have to reopen audio project.
	
Bank keys are [ and ]. 

Page up and down keys are pageup and pagedown.

There will be a slight pause after the bank key while the fader postions update.


right shift is "shift"
right alt is "alt"
right ctrl is "control"
/ key is "option"

punch in  = p single press

punch out = p double press

L = Loop on/off

There are others - they will be added

Please do not release it to the wild... it is not finished etc... etc..

::::::::::::::::
:: WHAT'S NEW ::
::::::::::::::::

LCD emulator - revised look.

:::::::::::::
:: LICENSE ::
:::::::::::::

Beverageware - see GenMce_Redux_EULA.txt for requirements.
Use at your own risk. Author is not liable for any use.

More detailed manual to follow.



:::::::::::::::::::::: �2007 - 2010 OneLeaf (Kip Chatterson) ::::::::::::::::::::::
